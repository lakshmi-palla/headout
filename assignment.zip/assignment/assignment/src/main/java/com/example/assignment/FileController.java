package com.example.assignment;



import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Optional;
import java.util.stream.Stream;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jakarta.persistence.criteria.Path;

@RestController
@RequestMapping("/data")
public class FileController {

    private static final String DATA_DIR = "/tmp/data/";

    @GetMapping
    public ResponseEntity<String> getFileData(@RequestParam(value = "n", required = false) String fileName,
                                              @RequestParam(value = "m", required = false) Integer lineNumber) {
        if (fileName == null || fileName.trim().isEmpty()) {
            return ResponseEntity.badRequest().body("File name is required");
        }

        java.nio.file.Path filePath = Paths.get(DATA_DIR + fileName + ".txt");
        if (!Files.exists(filePath)) {
            return ResponseEntity.notFound().build();
        }

        try {
            if (lineNumber == null) {
                // Return the entire file content
                String content = Files.readString(filePath);
                return ResponseEntity.ok(content);
            } else {
                // Return specific line
                try (Stream<String> lines = Files.lines(filePath)) {
                    Optional<String> lineContent = lines.skip(lineNumber - 1).findFirst();
                    return lineContent.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
                }
            }
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error reading file");
        }
    }
}
